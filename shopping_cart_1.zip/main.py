# -*- coding: utf-8 -*-
"""
Created on Sun Oct 12 10:20:39 2025

@author: pooji
"""

from shopping_cart import ShoppingCart
from item import Item
from exceptions import ItemNotFoundError

def main():
    """
    Main function that provides a menu-driven program
    for interacting with the Shopping Cart system.
    Users can add, remove, view items, and check total price.
    """
    
    cart = ShoppingCart()# Create a new empty shopping cart

    while True:
        # Display menu options
        print("\n--- Shopping Cart Menu ---")
        print("1. Add Item")
        print("2. Remove Item")
        print("3. View Cart")
        print("4. Show Cart Length")
        print("5. Check if Item Exists")
        print("6. Total Price")
        print("7. Exit")
        # Display menu options
        choice = input("Enter choice: ")
        
        # Option 1: Add an item to the cart
        if choice == "1":
            name = input("Enter item name: ")
            price = float(input("Enter item price: "))
            quantity = int(input("Enter quantity: "))
            item = Item(name, price, quantity)# Create Item object
            cart.add_item(item)# Add item to cart
            print(f"{name} added to cart successfully.")
        
        # Option 2: Remove an item from the cart
        elif choice == "2":
            name = input("Enter item name to remove: ")
            try:
                cart.remove_item(name)# Try removing the item
                print(f"{name} removed from cart.")
            except ItemNotFoundError as e:
                # Handle case when item is not found
                print(e)
        
        # Option 3: Display all items in the cart
        elif choice == "3":
            print(cart)

        
        # Option 4: Show number of items in the cart
        elif choice == "4":
            print(f"Number of items in cart: {len(cart)}")
        
        # Option 5: Check if a specific item exists in the cart
        elif choice == "5":
            name = input("Enter item name to check: ")
            if name in cart:
                print(f"{name} is in your cart.")
            else:
                print(f"{name} not found in your cart.")
        
        # Option 6: Show total price of all items in the cart
        elif choice == "6":
            print(f"Total price: ₹{cart.total_price()}")
        
        # Option 7: Exit the program
        elif choice == "7":
            print("Exiting the Shopping Cart. Thank you!")
            break
        
        # Invalid input handling
        else:
            print("Invalid choice. Please try again.")

# Run the main program only if this file is executed directl
if __name__ == "__main__":
    main()
