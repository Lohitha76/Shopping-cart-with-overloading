# -*- coding: utf-8 -*-
"""
Created on Sun Oct 12 10:19:59 2025

@author: pooji
"""

from item import Item
from exceptions import ItemNotFoundError
"""
ShoppingCart class that manages a collection of items.
This class allows adding, removing, and displaying items in a cart.
It stores all items as a list of Item objects.
"""


class ShoppingCart:
    def __init__(self):
       
        """
        Initialize an empty shopping cart.
        'self.items' is a list that holds Item objects.
        """
        self.items=[]

    def add_item(self, item):
        """
       Add an Item object to the shopping cart.
       """
        self.items.append(item)
            

    def remove_item(self, item_name):
        """
        Remove an item from the cart by its name.
        If the item is not found, raise ItemNotFoundError.
        """
        for item in self.items:
            if item_name==item.name:
                self.items.remove(item)
                return 
            
         # If loop finishes without finding the item
        raise ItemNotFoundError(f"{item_name} not found in shopping cart")
        
        
        

    def total_price(self):
        
        """
        Calculate the total cost of all items in the cart.
        Formula: sum of (item.price * item.quantity) for every item.
        """
        return sum(item.price*item.quantity for item in self.items)
    
        
        

    def __len__(self):
        
        """
        Return the number of items in the shopping cart.
        """
        return len(self.items)
        

    def __getitem__(self, index):
        
        """
        Allow accessing items in the cart using an index.
        Example: cart[0] → first item in the list.
        """
        return self.items[index]
        
        
    def __contains__(self, item_name):
        
        """
       Check if an item with the given name exists in the cart.
       Returns True or False.
       Example: 'Apple' in cart → True if item is present.
       """
        return any(item.name==item_name for item in self.items)
        
        

    def __add__(self, other):
        """
        Overload the '+' operator to add items or merge carts.
        - If 'other' is an Item → add it to the current cart.
        - If 'other' is another ShoppingCart → combine their items.
        - Otherwise, raise a TypeError.
        """
        if isinstance(other,Item):
            self.add_item(other)
        elif isinstance(other,ShoppingCart):
            self.items.extend(other.items)
        else:
            raise TypeError("Can only add item or shopping cart to the ShoppingCart")
        return self

    def __str__(self):
        
        """
        Return a readable string showing:
        - All items in the cart.
        - The total price of the cart.
        """
        
        if not self.items:
            return "Your ShoppingCart is empty"
        
        # Join all item details into one string
        details="\n".join(str(item) for item in self.items)
        return f"Items in your cart:\n{details}\nTotalprice:{self.total_price()}"

