# -*- coding: utf-8 -*-
"""
Created on Sun Oct 12 10:20:27 2025

@author: pooji
"""

#Raised an error when item is not found in the shopping cart
class ItemNotFoundError(Exception):
    
    """
    Raised when an item that the user tries to remove
    is not found in the shopping cart.
    Inherits from the built-in Exception class.
    """
    pass
