# -*- coding: utf-8 -*-
"""
Created on Sun Oct 12 10:19:36 2025

@author: pooji
"""
# Define a class to represent an item in the shopping cart
class Item:
    def __init__(self,name,price,quantity):
        # Initialize item attributes
        self.name=name
        self.price=price
        self.quantity=quantity
        
    # Method to return a string representation of the item
    def __str__(self):
        return f'Name:{self.name},Price:{self.name} and Quantity:{self.quantity}'
        
