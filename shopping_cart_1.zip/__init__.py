# -*- coding: utf-8 -*-
"""
Created on Sun Oct 12 10:20:53 2025

@author: pooji
"""

